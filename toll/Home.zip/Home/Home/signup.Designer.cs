﻿
namespace Home
{
    partial class signup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(signup));
            this.already = new System.Windows.Forms.Label();
            this.login = new System.Windows.Forms.Button();
            this.Sign_up = new System.Windows.Forms.Button();
            this.home = new System.Windows.Forms.Button();
            this.dobdtp = new System.Windows.Forms.DateTimePicker();
            this.passwordtb = new System.Windows.Forms.TextBox();
            this.fullnametb = new System.Windows.Forms.TextBox();
            this.phonenumbertb = new System.Windows.Forms.TextBox();
            this.usernametb = new System.Windows.Forms.TextBox();
            this.dob = new System.Windows.Forms.Label();
            this.phonenumber = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.Label();
            this.fullname = new System.Windows.Forms.Label();
            this.username = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // already
            // 
            this.already.AutoSize = true;
            this.already.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.already.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.already.Location = new System.Drawing.Point(200, 328);
            this.already.Name = "already";
            this.already.Size = new System.Drawing.Size(182, 17);
            this.already.TabIndex = 27;
            this.already.Text = "Already Have a Account";
            // 
            // login
            // 
            this.login.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.login.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.login.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.login.Location = new System.Drawing.Point(240, 363);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(92, 44);
            this.login.TabIndex = 26;
            this.login.Text = "Login";
            this.login.UseVisualStyleBackColor = false;
            this.login.Click += new System.EventHandler(this.login_Click);
            // 
            // Sign_up
            // 
            this.Sign_up.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Sign_up.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sign_up.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sign_up.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Sign_up.Location = new System.Drawing.Point(302, 271);
            this.Sign_up.Name = "Sign_up";
            this.Sign_up.Size = new System.Drawing.Size(91, 44);
            this.Sign_up.TabIndex = 25;
            this.Sign_up.Text = "Signup";
            this.Sign_up.UseVisualStyleBackColor = false;
            this.Sign_up.Click += new System.EventHandler(this.Sign_up_Click);
            // 
            // home
            // 
            this.home.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.home.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.home.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.home.Location = new System.Drawing.Point(188, 271);
            this.home.Name = "home";
            this.home.Size = new System.Drawing.Size(92, 44);
            this.home.TabIndex = 24;
            this.home.Text = "Home";
            this.home.UseVisualStyleBackColor = false;
            this.home.Click += new System.EventHandler(this.home_Click);
            // 
            // dobdtp
            // 
            this.dobdtp.Location = new System.Drawing.Point(188, 223);
            this.dobdtp.Name = "dobdtp";
            this.dobdtp.Size = new System.Drawing.Size(205, 20);
            this.dobdtp.TabIndex = 23;
            // 
            // passwordtb
            // 
            this.passwordtb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordtb.Location = new System.Drawing.Point(188, 94);
            this.passwordtb.Name = "passwordtb";
            this.passwordtb.PasswordChar = '*';
            this.passwordtb.Size = new System.Drawing.Size(205, 21);
            this.passwordtb.TabIndex = 22;
            // 
            // fullnametb
            // 
            this.fullnametb.Location = new System.Drawing.Point(188, 139);
            this.fullnametb.Name = "fullnametb";
            this.fullnametb.Size = new System.Drawing.Size(205, 20);
            this.fullnametb.TabIndex = 21;
            // 
            // phonenumbertb
            // 
            this.phonenumbertb.Location = new System.Drawing.Point(188, 182);
            this.phonenumbertb.Name = "phonenumbertb";
            this.phonenumbertb.Size = new System.Drawing.Size(205, 20);
            this.phonenumbertb.TabIndex = 20;
            // 
            // usernametb
            // 
            this.usernametb.Location = new System.Drawing.Point(188, 53);
            this.usernametb.Name = "usernametb";
            this.usernametb.Size = new System.Drawing.Size(205, 20);
            this.usernametb.TabIndex = 19;
            // 
            // dob
            // 
            this.dob.AutoSize = true;
            this.dob.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dob.Location = new System.Drawing.Point(91, 225);
            this.dob.Name = "dob";
            this.dob.Size = new System.Drawing.Size(33, 15);
            this.dob.TabIndex = 18;
            this.dob.Text = "DOB";
            // 
            // phonenumber
            // 
            this.phonenumber.AutoSize = true;
            this.phonenumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phonenumber.Location = new System.Drawing.Point(91, 183);
            this.phonenumber.Name = "phonenumber";
            this.phonenumber.Size = new System.Drawing.Size(91, 15);
            this.phonenumber.TabIndex = 17;
            this.phonenumber.Text = "Phone Number";
            // 
            // password
            // 
            this.password.AutoSize = true;
            this.password.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password.Location = new System.Drawing.Point(91, 94);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(61, 15);
            this.password.TabIndex = 16;
            this.password.Text = "Password";
            // 
            // fullname
            // 
            this.fullname.AutoSize = true;
            this.fullname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fullname.Location = new System.Drawing.Point(91, 140);
            this.fullname.Name = "fullname";
            this.fullname.Size = new System.Drawing.Size(64, 15);
            this.fullname.TabIndex = 15;
            this.fullname.Text = "Full Name";
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.username.Location = new System.Drawing.Point(91, 54);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(70, 15);
            this.username.TabIndex = 14;
            this.username.Text = "User Name";
            // 
            // signup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 461);
            this.Controls.Add(this.already);
            this.Controls.Add(this.login);
            this.Controls.Add(this.Sign_up);
            this.Controls.Add(this.home);
            this.Controls.Add(this.dobdtp);
            this.Controls.Add(this.passwordtb);
            this.Controls.Add(this.fullnametb);
            this.Controls.Add(this.phonenumbertb);
            this.Controls.Add(this.usernametb);
            this.Controls.Add(this.dob);
            this.Controls.Add(this.phonenumber);
            this.Controls.Add(this.password);
            this.Controls.Add(this.fullname);
            this.Controls.Add(this.username);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "signup";
            this.Text = "signup";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label already;
        private System.Windows.Forms.Button login;
        private System.Windows.Forms.Button Sign_up;
        private System.Windows.Forms.Button home;
        private System.Windows.Forms.DateTimePicker dobdtp;
        private System.Windows.Forms.TextBox passwordtb;
        private System.Windows.Forms.TextBox fullnametb;
        private System.Windows.Forms.TextBox phonenumbertb;
        private System.Windows.Forms.TextBox usernametb;
        private System.Windows.Forms.Label dob;
        private System.Windows.Forms.Label phonenumber;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.Label fullname;
        private System.Windows.Forms.Label username;
    }
}