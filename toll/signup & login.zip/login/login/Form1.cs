﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace login
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void loginbtn_Click(object sender, EventArgs e)
        {
            int x = usernametb.Text.Length;
            int y = passwordtb.Text.Length;
            if (x == 0 && y == 0 )
            {
                unerror.Visible = true;
                passerror.Visible = true;
            }
            if (x == 0)
            {
                unerror.Visible = true;
            }
            if (y == 0)
            {
                passerror.Visible = true;
            }
            if (x != 0 && y != 0)
            {
                unerror.Visible = false;
                passerror.Visible = false;
            }
            if (x != 0)
            {
                unerror.Visible = false;
            }
            if (y != 0)
            {
                passerror.Visible = false;
            } 
        }

    }
}
