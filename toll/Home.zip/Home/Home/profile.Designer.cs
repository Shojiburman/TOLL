﻿namespace Home
{
    partial class profile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(profile));
            this.addVehiclebtn = new System.Windows.Forms.Button();
            this.payTollbtn = new System.Windows.Forms.Button();
            this.transactionListbtn = new System.Windows.Forms.Button();
            this.tollListbtn = new System.Windows.Forms.Button();
            this.changePassworsBtn = new System.Windows.Forms.Button();
            this.vehicleListbtn = new System.Windows.Forms.Button();
            this.logoutbtn = new System.Windows.Forms.Button();
            this.untextbox = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // addVehiclebtn
            // 
            this.addVehiclebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.addVehiclebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addVehiclebtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.addVehiclebtn.Location = new System.Drawing.Point(49, 74);
            this.addVehiclebtn.Name = "addVehiclebtn";
            this.addVehiclebtn.Size = new System.Drawing.Size(147, 39);
            this.addVehiclebtn.TabIndex = 16;
            this.addVehiclebtn.Text = "Add Vehicle";
            this.addVehiclebtn.UseVisualStyleBackColor = false;
            this.addVehiclebtn.Click += new System.EventHandler(this.addVehiclebtn_Click);
            // 
            // payTollbtn
            // 
            this.payTollbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.payTollbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.payTollbtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.payTollbtn.Location = new System.Drawing.Point(49, 149);
            this.payTollbtn.Name = "payTollbtn";
            this.payTollbtn.Size = new System.Drawing.Size(147, 39);
            this.payTollbtn.TabIndex = 17;
            this.payTollbtn.Text = "Pay Toll";
            this.payTollbtn.UseVisualStyleBackColor = false;
            this.payTollbtn.Click += new System.EventHandler(this.payTollbtn_Click);
            // 
            // transactionListbtn
            // 
            this.transactionListbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.transactionListbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.transactionListbtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.transactionListbtn.Location = new System.Drawing.Point(49, 228);
            this.transactionListbtn.Name = "transactionListbtn";
            this.transactionListbtn.Size = new System.Drawing.Size(147, 39);
            this.transactionListbtn.TabIndex = 18;
            this.transactionListbtn.Text = "Transaction List";
            this.transactionListbtn.UseVisualStyleBackColor = false;
            this.transactionListbtn.Click += new System.EventHandler(this.transactionListbtn_Click);
            // 
            // tollListbtn
            // 
            this.tollListbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.tollListbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tollListbtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.tollListbtn.Location = new System.Drawing.Point(272, 150);
            this.tollListbtn.Name = "tollListbtn";
            this.tollListbtn.Size = new System.Drawing.Size(147, 39);
            this.tollListbtn.TabIndex = 21;
            this.tollListbtn.Text = "Toll List";
            this.tollListbtn.UseVisualStyleBackColor = false;
            this.tollListbtn.Click += new System.EventHandler(this.tollListbtn_Click);
            // 
            // changePassworsBtn
            // 
            this.changePassworsBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.changePassworsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.changePassworsBtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.changePassworsBtn.Location = new System.Drawing.Point(272, 228);
            this.changePassworsBtn.Name = "changePassworsBtn";
            this.changePassworsBtn.Size = new System.Drawing.Size(147, 39);
            this.changePassworsBtn.TabIndex = 22;
            this.changePassworsBtn.Text = "Change Password";
            this.changePassworsBtn.UseVisualStyleBackColor = false;
            this.changePassworsBtn.Click += new System.EventHandler(this.changePassworsBtn_Click);
            // 
            // vehicleListbtn
            // 
            this.vehicleListbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.vehicleListbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.vehicleListbtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.vehicleListbtn.Location = new System.Drawing.Point(272, 74);
            this.vehicleListbtn.Name = "vehicleListbtn";
            this.vehicleListbtn.Size = new System.Drawing.Size(147, 39);
            this.vehicleListbtn.TabIndex = 24;
            this.vehicleListbtn.Text = "Vehicle List";
            this.vehicleListbtn.UseVisualStyleBackColor = false;
            this.vehicleListbtn.Click += new System.EventHandler(this.vehicleListbtn_Click);
            // 
            // logoutbtn
            // 
            this.logoutbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.logoutbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logoutbtn.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.logoutbtn.Location = new System.Drawing.Point(158, 308);
            this.logoutbtn.Name = "logoutbtn";
            this.logoutbtn.Size = new System.Drawing.Size(147, 39);
            this.logoutbtn.TabIndex = 25;
            this.logoutbtn.Text = "Logout";
            this.logoutbtn.UseVisualStyleBackColor = false;
            this.logoutbtn.Click += new System.EventHandler(this.logoutbtn_Click);
            // 
            // untextbox
            // 
            this.untextbox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.untextbox.BackColor = System.Drawing.SystemColors.Control;
            this.untextbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.untextbox.Location = new System.Drawing.Point(87, 23);
            this.untextbox.Multiline = true;
            this.untextbox.Name = "untextbox";
            this.untextbox.ReadOnly = true;
            this.untextbox.Size = new System.Drawing.Size(332, 20);
            this.untextbox.TabIndex = 26;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(49, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(38, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 28;
            this.pictureBox1.TabStop = false;
            // 
            // profile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 461);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.untextbox);
            this.Controls.Add(this.logoutbtn);
            this.Controls.Add(this.vehicleListbtn);
            this.Controls.Add(this.changePassworsBtn);
            this.Controls.Add(this.tollListbtn);
            this.Controls.Add(this.transactionListbtn);
            this.Controls.Add(this.payTollbtn);
            this.Controls.Add(this.addVehiclebtn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "profile";
            this.Text = "profile";
            this.Load += new System.EventHandler(this.profile_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button addVehiclebtn;
        private System.Windows.Forms.Button payTollbtn;
        private System.Windows.Forms.Button transactionListbtn;
        private System.Windows.Forms.Button tollListbtn;
        private System.Windows.Forms.Button changePassworsBtn;
        private System.Windows.Forms.Button vehicleListbtn;
        private System.Windows.Forms.Button logoutbtn;
        internal System.Windows.Forms.TextBox untextbox;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}